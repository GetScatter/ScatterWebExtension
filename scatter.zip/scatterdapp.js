/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 135);
/******/ })
/************************************************************************/
/******/ ({

/***/ 112:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

const INJECTED = 'injected';
/* harmony export (immutable) */ __webpack_exports__["a"] = INJECTED;

const SCATTER = 'scatter';
/* harmony export (immutable) */ __webpack_exports__["b"] = SCATTER;


/***/ }),

/***/ 116:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__models_Network__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__NetworkMessageTypes__ = __webpack_require__(57);



class NetworkMessage {

    constructor(_type = '', _payload = {}, _resolver = '', _network = null, _domain = ''){
        this.type = _type;
        this.payload = _payload;
        this.resolver = _resolver;
        this.network = _network;
        this.domain = _domain;
    }

    static placeholder(){ return new NetworkMessage(); }
    static fromJson(json){
        let p = Object.assign(this.placeholder(), json);
        if(json.hasOwnProperty('network')) p.network = __WEBPACK_IMPORTED_MODULE_0__models_Network__["default"].fromJson(json.network);
        return p;
    }

    static payload(type, payload){
        let p = this.placeholder();
        p.type = type;
        p.payload = payload;
        return p;
    }

    static signal(type){
        let p = this.placeholder();
        p.type = type;
        return p;
    }

    respond(payload){ return new NetworkMessage(this.type, payload, this.resolver); }
    error(payload){ return new NetworkMessage(__WEBPACK_IMPORTED_MODULE_1__NetworkMessageTypes__["a" /* ERROR */], payload, this.resolver); }
}
/* harmony export (immutable) */ __webpack_exports__["a"] = NetworkMessage;


/***/ }),

/***/ 135:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__messages_NetworkMessage__ = __webpack_require__(116);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__messages_NetworkMessageTypes__ = __webpack_require__(57);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__messages_PairingTags__ = __webpack_require__(112);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_IdGenerator__ = __webpack_require__(30);






const throws = (msg) => {
    throw new Error(msg);
};

/***
 * This is just a helper to manage resolving fake-async
 * requests using browser messaging.
 */
class DanglingResolver {
    constructor(_id, _resolve, _reject){
        this.id = _id;
        this.resolve = _resolve;
        this.reject = _reject;
    }
}

// Removing properties from exposed scatterdapp object
// Pseudo privacy
let provider = new WeakMap();
let stream = new WeakMap();
let resolvers = new WeakMap();

// This is used to verify that private method calls came
// explicitly from inside the class
let instanceRef = new WeakMap();
instanceRef = __WEBPACK_IMPORTED_MODULE_3__util_IdGenerator__["a" /* default */].text(128);

/***
 * Scatterdapp is the object injected into the web application that
 * allows it to interact with Scatter. Without using this the web application
 * has no access to the extension.
 */
class Scatterdapp {

    constructor(_stream){
        this.network = null;
        stream = _stream;
        resolvers = [];
        this._subscribe(instanceRef);

        // Sets up the provider to be used by eosjs
        provider = async signargs => {
            const domain = location.host;
            const network = this.network;
            await this._send(__WEBPACK_IMPORTED_MODULE_1__messages_NetworkMessageTypes__["d" /* REQUEST_SIGNATURE */],
                Object.assign(signargs, {domain, network})
            , instanceRef);
        }
    }



    /********************************/
    /*                              */
    /*           Private            */
    /*     --------------------     */
    /*     Methods here are         */
    /*     protected using weak     */
    /*     maps and a random id     */
    /*                              */
    /********************************/

    /***
     * Messages do not come back on the same thread.
     * To accomplish a future promise structure this method
     * catches all incoming messages and dispenses
     * them to the open promises. */
    _subscribe(_instanceRef) {
        if(instanceRef !== _instanceRef) throws('Can only subscribe internally.');

        stream.listenWith(msg => {
            if(!msg || !msg.hasOwnProperty('type')) return false;
            for(let i=0; i < resolvers.length; i++) {
                if (resolvers[i].id === msg.resolver) {
                    if(msg.type === 'error') resolvers[i].reject(msg.payload);
                    else resolvers[i].resolve(msg.payload);
                    resolvers = resolvers.slice(i, 1);
                }
            }
        });
    }

    /***
     * Binds a network to this instance of scatterdapp.
     * Only one network can be bound, and it cannot be re-bound.
     * @param _network
     * @param _instanceRef
     * @returns {boolean}
     */
    _bindNetwork(_network, _instanceRef){
        if(instanceRef !== _instanceRef) throws('Can only bind network internally.');

        if(this.network)
            throws("You can only bind a network once.");

        if(!_network || !_network.hasOwnProperty('host') || !_network.hasOwnProperty('port'))
            throws('Malformed network. { host:string, port:number }');

        if(isNaN(_network.port) || !_network.host.length || _network.host.indexOf('.') === -1)
            throws('"port" must be a number and "host" must be a string of a domain or an ip.');

        this.network = _network;
    }

    /***
     * Only a Scatterdapp which has had a network bound to it
     * can be used.
     * @param _reject
     * @param _runIfNetworkBound
     * @param _instanceRef
     */
    _networkGuard(_reject, _runIfNetworkBound, _instanceRef){
        if(instanceRef !== _instanceRef) throws('Can only check network guard internally.');

        if(!this.network) {
            throws(`It seems that a network was not set. 
                Did you create your eosjs instance using scatter.eos() ?`);
            _reject(null);
        }
        _runIfNetworkBound();
    }

    /***
     * Turns message sending between the application
     * and the content script into async promises
     * @param _type
     * @param _payload
     * @param _instanceRef
     */
    _send(_type, _payload, _instanceRef) {
        if(instanceRef !== _instanceRef) throws('Can only send messages internally.');

        return new Promise((resolve, reject) => {
            this._networkGuard(reject, () => {
                let id = __WEBPACK_IMPORTED_MODULE_3__util_IdGenerator__["a" /* default */].numeric(6);
                let message = new __WEBPACK_IMPORTED_MODULE_0__messages_NetworkMessage__["a" /* default */](_type, _payload, id, this.network, location.host);
                resolvers.push(new DanglingResolver(id, resolve, reject));
                stream.send(message, __WEBPACK_IMPORTED_MODULE_2__messages_PairingTags__["b" /* SCATTER */]);
            }, _instanceRef);
        })

    }




    /********************************/
    /*                              */
    /*           Public             */
    /*                              */
    /********************************/

    /***
     * Returns an instance of eosjs with a signature provider and endpoint bound
     * to it. Adds a level of security over signature provider manipulation.
     * No matter what options are provided, httpEndpoint and signProvider are always overwritten.
     * @param _eos - An instance of Eos.Localnet or Eos.Testnet
     * @param _network - The network you are binding to {host:string, port:number}
     * @param _options - Passable object of eosjs options
     * @returns {*}
     */
    eos(_eos, _network, _options = {}){
        this._bindNetwork(_network, instanceRef);
        const httpEndpoint = `http://${_network.host}:${_network.port}`;
        return _eos(Object.assign(_options, {httpEndpoint, signProvider: provider}))
    }


    /***
     * Gets an Identity from the user to use.
     * You shouldn't rely on the state of this object to be immutable.
     * Identities are subject to change and if you use values you saved in
     * a database vs the values on the identity currently signature providers will not work.
     * @param fields - You can specify required fields such as ['email', 'country', 'firstname']
     */
    getIdentity(fields = []){
        return this._send(__WEBPACK_IMPORTED_MODULE_1__messages_NetworkMessageTypes__["b" /* GET_OR_REQUEST_IDENTITY */], {
            domain:location.host,
            network:this.network,
            fields
        }, instanceRef);
    }

}
/* harmony export (immutable) */ __webpack_exports__["default"] = Scatterdapp;


/***/ }),

/***/ 21:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
class Network {
    constructor(_host = '', _port = 0){
        this.host = _host;
        this.port = _port;
    }

    static placeholder(){ return new Network(); }
    static fromJson(json){ return Object.assign(this.placeholder(), json); }
    unique(){ return `${this.host}:${this.port}`; }
    clone(){ return Network.fromJson(JSON.parse(JSON.stringify(this))) }

    /***
     * The endorsed Scatter network that holds it's contracts
     * @returns {Network}
     */
    static endorsedNetwork(){ return new Network('mainnet.eos.io', 8080); }

    /***
     * Checks if this is the Scatter endorsed network
     * @returns {boolean}
     */
    isEndorsedNetwork(){ return this.host === 'mainnet.eos.io' && this.port === 8080 }

    /***
     * Makes sure a port is not reserved
     * @param port
     * @returns {boolean}
     */
    static portIsValid(port){ return Number(port) > 1000 || Number(port) === 80 }

    // TODO: Mock
    static hostIsValid(host){ return host.indexOf('.') > -1 }

}
/* harmony export (immutable) */ __webpack_exports__["default"] = Network;


/***/ }),

/***/ 30:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
class IdGenerator {

    /***
     * Generates a random string of specified size
     * @param size - The length of the string to generate
     * @returns {string} - The generated random string
     */
    static text(size){
        let text = "";
        const possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for(let i=0; i<size; i++) text += possible.charAt(Math.floor(Math.random() * possible.length));
        return text;
    }

    /***
     * Generates a random number of specified size
     * @param size - The length of the number to generate
     * @returns {string} - The generated random number ( as a string )
     */
    static numeric(size){
        const add = 1;
        let max = 12 - add;

        if ( size > max ) return IdGenerator.numeric(max) + IdGenerator.numeric(size - max);

        max = Math.pow(10, size+add);
        const min = max / 10,
              number = Math.floor(Math.random() * (max - min + 1)) + min;

        return ("" + number).substring(add);
    }

}
/* harmony export (immutable) */ __webpack_exports__["a"] = IdGenerator;


/***/ }),

/***/ 57:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const ERROR = 'error';
/* harmony export (immutable) */ __webpack_exports__["a"] = ERROR;

const PUSH_SCATTER = 'pushScatter';
/* harmony export (immutable) */ __webpack_exports__["c"] = PUSH_SCATTER;

const GET_OR_REQUEST_IDENTITY = 'getOrRequestIdentity';
/* harmony export (immutable) */ __webpack_exports__["b"] = GET_OR_REQUEST_IDENTITY;

const REQUEST_SIGNATURE = 'requestSignature';
/* harmony export (immutable) */ __webpack_exports__["d"] = REQUEST_SIGNATURE;


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgYjI2MmNkOWNjNTM0NGU2NTU2MTAiLCJ3ZWJwYWNrOi8vLy4vc3JjL21lc3NhZ2VzL1BhaXJpbmdUYWdzLmpzIiwid2VicGFjazovLy8uL3NyYy9tZXNzYWdlcy9OZXR3b3JrTWVzc2FnZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2NhdHRlcmRhcHAuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZGVscy9OZXR3b3JrLmpzIiwid2VicGFjazovLy8uL3NyYy91dGlsL0lkR2VuZXJhdG9yLmpzIiwid2VicGFjazovLy8uL3NyYy9tZXNzYWdlcy9OZXR3b3JrTWVzc2FnZVR5cGVzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBSztBQUNMO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsbUNBQTJCLDBCQUEwQixFQUFFO0FBQ3ZELHlDQUFpQyxlQUFlO0FBQ2hEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDhEQUFzRCwrREFBK0Q7O0FBRXJIO0FBQ0E7O0FBRUE7QUFDQTs7Ozs7Ozs7OztBQzVEQTtBQUFBO0FBQUE7QUFDQSwwQjs7Ozs7Ozs7Ozs7O0FDRkE7QUFDQTs7QUFFQTs7QUFFQSx5Q0FBeUM7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHlCQUF5Qiw2QkFBNkI7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxxQkFBcUIsOERBQThEO0FBQ25GLG1CQUFtQix3SEFBOEU7QUFDakcsQzs7Ozs7Ozs7Ozs7Ozs7O0FDbkNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUMsZ0JBQWdCO0FBQ3pEO0FBQ0E7QUFDQTs7OztBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0Esd0JBQXdCLHNCQUFzQjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBLHdDQUF3QywyQkFBMkI7O0FBRW5FO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTOztBQUVUOzs7OztBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlEQUF5RDtBQUN6RDtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLHFDQUFxQztBQUNyQztBQUNBLHVDQUF1QyxjQUFjLEdBQUcsY0FBYztBQUN0RSw2Q0FBNkMscUNBQXFDO0FBQ2xGOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7O0FBRUEsQzs7Ozs7Ozs7Ozs7QUM3TEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSx5QkFBeUIsc0JBQXNCO0FBQy9DLDBCQUEwQixnREFBZ0Q7QUFDMUUsYUFBYSxXQUFXLFVBQVUsR0FBRyxVQUFVLEVBQUU7QUFDakQsWUFBWTs7QUFFWjtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsNkJBQTZCLDRDQUE0Qzs7QUFFekU7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLHdCQUF3Qjs7QUFFeEI7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsNkJBQTZCOztBQUU3QjtBQUNBLDZCQUE2Qjs7QUFFN0IsQzs7Ozs7Ozs7OztBQ2pDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsT0FBTztBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixRQUFRO0FBQzVCO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLE9BQU87QUFDeEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsQzs7Ozs7Ozs7OztBQ2hDQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFDQSw2QyIsImZpbGUiOiJzY2F0dGVyZGFwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwge1xuIFx0XHRcdFx0Y29uZmlndXJhYmxlOiBmYWxzZSxcbiBcdFx0XHRcdGVudW1lcmFibGU6IHRydWUsXG4gXHRcdFx0XHRnZXQ6IGdldHRlclxuIFx0XHRcdH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IDEzNSk7XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gd2VicGFjay9ib290c3RyYXAgYjI2MmNkOWNjNTM0NGU2NTU2MTAiLCJcclxuZXhwb3J0IGNvbnN0IElOSkVDVEVEID0gJ2luamVjdGVkJztcclxuZXhwb3J0IGNvbnN0IFNDQVRURVIgPSAnc2NhdHRlcic7XG5cblxuLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBXRUJQQUNLIEZPT1RFUlxuLy8gLi9zcmMvbWVzc2FnZXMvUGFpcmluZ1RhZ3MuanNcbi8vIG1vZHVsZSBpZCA9IDExMlxuLy8gbW9kdWxlIGNodW5rcyA9IDEgMyA0IiwiaW1wb3J0IE5ldHdvcmsgZnJvbSAnLi4vbW9kZWxzL05ldHdvcmsnXHJcbmltcG9ydCAqIGFzIE5ldHdvcmtNZXNzYWdlVHlwZXMgZnJvbSAnLi9OZXR3b3JrTWVzc2FnZVR5cGVzJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE5ldHdvcmtNZXNzYWdlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihfdHlwZSA9ICcnLCBfcGF5bG9hZCA9IHt9LCBfcmVzb2x2ZXIgPSAnJywgX25ldHdvcmsgPSBudWxsLCBfZG9tYWluID0gJycpe1xyXG4gICAgICAgIHRoaXMudHlwZSA9IF90eXBlO1xyXG4gICAgICAgIHRoaXMucGF5bG9hZCA9IF9wYXlsb2FkO1xyXG4gICAgICAgIHRoaXMucmVzb2x2ZXIgPSBfcmVzb2x2ZXI7XHJcbiAgICAgICAgdGhpcy5uZXR3b3JrID0gX25ldHdvcms7XHJcbiAgICAgICAgdGhpcy5kb21haW4gPSBfZG9tYWluO1xyXG4gICAgfVxyXG5cclxuICAgIHN0YXRpYyBwbGFjZWhvbGRlcigpeyByZXR1cm4gbmV3IE5ldHdvcmtNZXNzYWdlKCk7IH1cclxuICAgIHN0YXRpYyBmcm9tSnNvbihqc29uKXtcclxuICAgICAgICBsZXQgcCA9IE9iamVjdC5hc3NpZ24odGhpcy5wbGFjZWhvbGRlcigpLCBqc29uKTtcclxuICAgICAgICBpZihqc29uLmhhc093blByb3BlcnR5KCduZXR3b3JrJykpIHAubmV0d29yayA9IE5ldHdvcmsuZnJvbUpzb24oanNvbi5uZXR3b3JrKTtcclxuICAgICAgICByZXR1cm4gcDtcclxuICAgIH1cclxuXHJcbiAgICBzdGF0aWMgcGF5bG9hZCh0eXBlLCBwYXlsb2FkKXtcclxuICAgICAgICBsZXQgcCA9IHRoaXMucGxhY2Vob2xkZXIoKTtcclxuICAgICAgICBwLnR5cGUgPSB0eXBlO1xyXG4gICAgICAgIHAucGF5bG9hZCA9IHBheWxvYWQ7XHJcbiAgICAgICAgcmV0dXJuIHA7XHJcbiAgICB9XHJcblxyXG4gICAgc3RhdGljIHNpZ25hbCh0eXBlKXtcclxuICAgICAgICBsZXQgcCA9IHRoaXMucGxhY2Vob2xkZXIoKTtcclxuICAgICAgICBwLnR5cGUgPSB0eXBlO1xyXG4gICAgICAgIHJldHVybiBwO1xyXG4gICAgfVxyXG5cclxuICAgIHJlc3BvbmQocGF5bG9hZCl7IHJldHVybiBuZXcgTmV0d29ya01lc3NhZ2UodGhpcy50eXBlLCBwYXlsb2FkLCB0aGlzLnJlc29sdmVyKTsgfVxyXG4gICAgZXJyb3IocGF5bG9hZCl7IHJldHVybiBuZXcgTmV0d29ya01lc3NhZ2UoTmV0d29ya01lc3NhZ2VUeXBlcy5FUlJPUiwgcGF5bG9hZCwgdGhpcy5yZXNvbHZlcik7IH1cclxufVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vc3JjL21lc3NhZ2VzL05ldHdvcmtNZXNzYWdlLmpzXG4vLyBtb2R1bGUgaWQgPSAxMTZcbi8vIG1vZHVsZSBjaHVua3MgPSAxIDMgNCIsImltcG9ydCBOZXR3b3JrTWVzc2FnZSBmcm9tICcuL21lc3NhZ2VzL05ldHdvcmtNZXNzYWdlJztcclxuaW1wb3J0ICogYXMgTmV0d29ya01lc3NhZ2VUeXBlcyBmcm9tICcuL21lc3NhZ2VzL05ldHdvcmtNZXNzYWdlVHlwZXMnXHJcbmltcG9ydCAqIGFzIFBhaXJpbmdUYWdzIGZyb20gJy4vbWVzc2FnZXMvUGFpcmluZ1RhZ3MnXHJcbmltcG9ydCBJZEdlbmVyYXRvciBmcm9tICcuL3V0aWwvSWRHZW5lcmF0b3InO1xyXG5cclxuXHJcbmNvbnN0IHRocm93cyA9IChtc2cpID0+IHtcclxuICAgIHRocm93IG5ldyBFcnJvcihtc2cpO1xyXG59O1xyXG5cclxuLyoqKlxyXG4gKiBUaGlzIGlzIGp1c3QgYSBoZWxwZXIgdG8gbWFuYWdlIHJlc29sdmluZyBmYWtlLWFzeW5jXHJcbiAqIHJlcXVlc3RzIHVzaW5nIGJyb3dzZXIgbWVzc2FnaW5nLlxyXG4gKi9cclxuY2xhc3MgRGFuZ2xpbmdSZXNvbHZlciB7XHJcbiAgICBjb25zdHJ1Y3RvcihfaWQsIF9yZXNvbHZlLCBfcmVqZWN0KXtcclxuICAgICAgICB0aGlzLmlkID0gX2lkO1xyXG4gICAgICAgIHRoaXMucmVzb2x2ZSA9IF9yZXNvbHZlO1xyXG4gICAgICAgIHRoaXMucmVqZWN0ID0gX3JlamVjdDtcclxuICAgIH1cclxufVxyXG5cclxuLy8gUmVtb3ZpbmcgcHJvcGVydGllcyBmcm9tIGV4cG9zZWQgc2NhdHRlcmRhcHAgb2JqZWN0XHJcbi8vIFBzZXVkbyBwcml2YWN5XHJcbmxldCBwcm92aWRlciA9IG5ldyBXZWFrTWFwKCk7XHJcbmxldCBzdHJlYW0gPSBuZXcgV2Vha01hcCgpO1xyXG5sZXQgcmVzb2x2ZXJzID0gbmV3IFdlYWtNYXAoKTtcclxuXHJcbi8vIFRoaXMgaXMgdXNlZCB0byB2ZXJpZnkgdGhhdCBwcml2YXRlIG1ldGhvZCBjYWxscyBjYW1lXHJcbi8vIGV4cGxpY2l0bHkgZnJvbSBpbnNpZGUgdGhlIGNsYXNzXHJcbmxldCBpbnN0YW5jZVJlZiA9IG5ldyBXZWFrTWFwKCk7XHJcbmluc3RhbmNlUmVmID0gSWRHZW5lcmF0b3IudGV4dCgxMjgpO1xyXG5cclxuLyoqKlxyXG4gKiBTY2F0dGVyZGFwcCBpcyB0aGUgb2JqZWN0IGluamVjdGVkIGludG8gdGhlIHdlYiBhcHBsaWNhdGlvbiB0aGF0XHJcbiAqIGFsbG93cyBpdCB0byBpbnRlcmFjdCB3aXRoIFNjYXR0ZXIuIFdpdGhvdXQgdXNpbmcgdGhpcyB0aGUgd2ViIGFwcGxpY2F0aW9uXHJcbiAqIGhhcyBubyBhY2Nlc3MgdG8gdGhlIGV4dGVuc2lvbi5cclxuICovXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFNjYXR0ZXJkYXBwIHtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihfc3RyZWFtKXtcclxuICAgICAgICB0aGlzLm5ldHdvcmsgPSBudWxsO1xyXG4gICAgICAgIHN0cmVhbSA9IF9zdHJlYW07XHJcbiAgICAgICAgcmVzb2x2ZXJzID0gW107XHJcbiAgICAgICAgdGhpcy5fc3Vic2NyaWJlKGluc3RhbmNlUmVmKTtcclxuXHJcbiAgICAgICAgLy8gU2V0cyB1cCB0aGUgcHJvdmlkZXIgdG8gYmUgdXNlZCBieSBlb3Nqc1xyXG4gICAgICAgIHByb3ZpZGVyID0gYXN5bmMgc2lnbmFyZ3MgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBkb21haW4gPSBsb2NhdGlvbi5ob3N0O1xyXG4gICAgICAgICAgICBjb25zdCBuZXR3b3JrID0gdGhpcy5uZXR3b3JrO1xyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLl9zZW5kKE5ldHdvcmtNZXNzYWdlVHlwZXMuUkVRVUVTVF9TSUdOQVRVUkUsXHJcbiAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKHNpZ25hcmdzLCB7ZG9tYWluLCBuZXR3b3JrfSlcclxuICAgICAgICAgICAgLCBpbnN0YW5jZVJlZik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLyogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAqL1xyXG4gICAgLyogICAgICAgICAgIFByaXZhdGUgICAgICAgICAgICAqL1xyXG4gICAgLyogICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tICAgICAqL1xyXG4gICAgLyogICAgIE1ldGhvZHMgaGVyZSBhcmUgICAgICAgICAqL1xyXG4gICAgLyogICAgIHByb3RlY3RlZCB1c2luZyB3ZWFrICAgICAqL1xyXG4gICAgLyogICAgIG1hcHMgYW5kIGEgcmFuZG9tIGlkICAgICAqL1xyXG4gICAgLyogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAqL1xyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuICAgIC8qKipcclxuICAgICAqIE1lc3NhZ2VzIGRvIG5vdCBjb21lIGJhY2sgb24gdGhlIHNhbWUgdGhyZWFkLlxyXG4gICAgICogVG8gYWNjb21wbGlzaCBhIGZ1dHVyZSBwcm9taXNlIHN0cnVjdHVyZSB0aGlzIG1ldGhvZFxyXG4gICAgICogY2F0Y2hlcyBhbGwgaW5jb21pbmcgbWVzc2FnZXMgYW5kIGRpc3BlbnNlc1xyXG4gICAgICogdGhlbSB0byB0aGUgb3BlbiBwcm9taXNlcy4gKi9cclxuICAgIF9zdWJzY3JpYmUoX2luc3RhbmNlUmVmKSB7XHJcbiAgICAgICAgaWYoaW5zdGFuY2VSZWYgIT09IF9pbnN0YW5jZVJlZikgdGhyb3dzKCdDYW4gb25seSBzdWJzY3JpYmUgaW50ZXJuYWxseS4nKTtcclxuXHJcbiAgICAgICAgc3RyZWFtLmxpc3RlbldpdGgobXNnID0+IHtcclxuICAgICAgICAgICAgaWYoIW1zZyB8fCAhbXNnLmhhc093blByb3BlcnR5KCd0eXBlJykpIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgZm9yKGxldCBpPTA7IGkgPCByZXNvbHZlcnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNvbHZlcnNbaV0uaWQgPT09IG1zZy5yZXNvbHZlcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKG1zZy50eXBlID09PSAnZXJyb3InKSByZXNvbHZlcnNbaV0ucmVqZWN0KG1zZy5wYXlsb2FkKTtcclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHJlc29sdmVyc1tpXS5yZXNvbHZlKG1zZy5wYXlsb2FkKTtcclxuICAgICAgICAgICAgICAgICAgICByZXNvbHZlcnMgPSByZXNvbHZlcnMuc2xpY2UoaSwgMSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqXHJcbiAgICAgKiBCaW5kcyBhIG5ldHdvcmsgdG8gdGhpcyBpbnN0YW5jZSBvZiBzY2F0dGVyZGFwcC5cclxuICAgICAqIE9ubHkgb25lIG5ldHdvcmsgY2FuIGJlIGJvdW5kLCBhbmQgaXQgY2Fubm90IGJlIHJlLWJvdW5kLlxyXG4gICAgICogQHBhcmFtIF9uZXR3b3JrXHJcbiAgICAgKiBAcGFyYW0gX2luc3RhbmNlUmVmXHJcbiAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn1cclxuICAgICAqL1xyXG4gICAgX2JpbmROZXR3b3JrKF9uZXR3b3JrLCBfaW5zdGFuY2VSZWYpe1xyXG4gICAgICAgIGlmKGluc3RhbmNlUmVmICE9PSBfaW5zdGFuY2VSZWYpIHRocm93cygnQ2FuIG9ubHkgYmluZCBuZXR3b3JrIGludGVybmFsbHkuJyk7XHJcblxyXG4gICAgICAgIGlmKHRoaXMubmV0d29yaylcclxuICAgICAgICAgICAgdGhyb3dzKFwiWW91IGNhbiBvbmx5IGJpbmQgYSBuZXR3b3JrIG9uY2UuXCIpO1xyXG5cclxuICAgICAgICBpZighX25ldHdvcmsgfHwgIV9uZXR3b3JrLmhhc093blByb3BlcnR5KCdob3N0JykgfHwgIV9uZXR3b3JrLmhhc093blByb3BlcnR5KCdwb3J0JykpXHJcbiAgICAgICAgICAgIHRocm93cygnTWFsZm9ybWVkIG5ldHdvcmsuIHsgaG9zdDpzdHJpbmcsIHBvcnQ6bnVtYmVyIH0nKTtcclxuXHJcbiAgICAgICAgaWYoaXNOYU4oX25ldHdvcmsucG9ydCkgfHwgIV9uZXR3b3JrLmhvc3QubGVuZ3RoIHx8IF9uZXR3b3JrLmhvc3QuaW5kZXhPZignLicpID09PSAtMSlcclxuICAgICAgICAgICAgdGhyb3dzKCdcInBvcnRcIiBtdXN0IGJlIGEgbnVtYmVyIGFuZCBcImhvc3RcIiBtdXN0IGJlIGEgc3RyaW5nIG9mIGEgZG9tYWluIG9yIGFuIGlwLicpO1xyXG5cclxuICAgICAgICB0aGlzLm5ldHdvcmsgPSBfbmV0d29yaztcclxuICAgIH1cclxuXHJcbiAgICAvKioqXHJcbiAgICAgKiBPbmx5IGEgU2NhdHRlcmRhcHAgd2hpY2ggaGFzIGhhZCBhIG5ldHdvcmsgYm91bmQgdG8gaXRcclxuICAgICAqIGNhbiBiZSB1c2VkLlxyXG4gICAgICogQHBhcmFtIF9yZWplY3RcclxuICAgICAqIEBwYXJhbSBfcnVuSWZOZXR3b3JrQm91bmRcclxuICAgICAqIEBwYXJhbSBfaW5zdGFuY2VSZWZcclxuICAgICAqL1xyXG4gICAgX25ldHdvcmtHdWFyZChfcmVqZWN0LCBfcnVuSWZOZXR3b3JrQm91bmQsIF9pbnN0YW5jZVJlZil7XHJcbiAgICAgICAgaWYoaW5zdGFuY2VSZWYgIT09IF9pbnN0YW5jZVJlZikgdGhyb3dzKCdDYW4gb25seSBjaGVjayBuZXR3b3JrIGd1YXJkIGludGVybmFsbHkuJyk7XHJcblxyXG4gICAgICAgIGlmKCF0aGlzLm5ldHdvcmspIHtcclxuICAgICAgICAgICAgdGhyb3dzKGBJdCBzZWVtcyB0aGF0IGEgbmV0d29yayB3YXMgbm90IHNldC4gXHJcbiAgICAgICAgICAgICAgICBEaWQgeW91IGNyZWF0ZSB5b3VyIGVvc2pzIGluc3RhbmNlIHVzaW5nIHNjYXR0ZXIuZW9zKCkgP2ApO1xyXG4gICAgICAgICAgICBfcmVqZWN0KG51bGwpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBfcnVuSWZOZXR3b3JrQm91bmQoKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqXHJcbiAgICAgKiBUdXJucyBtZXNzYWdlIHNlbmRpbmcgYmV0d2VlbiB0aGUgYXBwbGljYXRpb25cclxuICAgICAqIGFuZCB0aGUgY29udGVudCBzY3JpcHQgaW50byBhc3luYyBwcm9taXNlc1xyXG4gICAgICogQHBhcmFtIF90eXBlXHJcbiAgICAgKiBAcGFyYW0gX3BheWxvYWRcclxuICAgICAqIEBwYXJhbSBfaW5zdGFuY2VSZWZcclxuICAgICAqL1xyXG4gICAgX3NlbmQoX3R5cGUsIF9wYXlsb2FkLCBfaW5zdGFuY2VSZWYpIHtcclxuICAgICAgICBpZihpbnN0YW5jZVJlZiAhPT0gX2luc3RhbmNlUmVmKSB0aHJvd3MoJ0NhbiBvbmx5IHNlbmQgbWVzc2FnZXMgaW50ZXJuYWxseS4nKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fbmV0d29ya0d1YXJkKHJlamVjdCwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGlkID0gSWRHZW5lcmF0b3IubnVtZXJpYyg2KTtcclxuICAgICAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3IE5ldHdvcmtNZXNzYWdlKF90eXBlLCBfcGF5bG9hZCwgaWQsIHRoaXMubmV0d29yaywgbG9jYXRpb24uaG9zdCk7XHJcbiAgICAgICAgICAgICAgICByZXNvbHZlcnMucHVzaChuZXcgRGFuZ2xpbmdSZXNvbHZlcihpZCwgcmVzb2x2ZSwgcmVqZWN0KSk7XHJcbiAgICAgICAgICAgICAgICBzdHJlYW0uc2VuZChtZXNzYWdlLCBQYWlyaW5nVGFncy5TQ0FUVEVSKTtcclxuICAgICAgICAgICAgfSwgX2luc3RhbmNlUmVmKTtcclxuICAgICAgICB9KVxyXG5cclxuICAgIH1cclxuXHJcblxyXG5cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICovXHJcbiAgICAvKiAgICAgICAgICAgUHVibGljICAgICAgICAgICAgICovXHJcbiAgICAvKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICovXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG4gICAgLyoqKlxyXG4gICAgICogUmV0dXJucyBhbiBpbnN0YW5jZSBvZiBlb3NqcyB3aXRoIGEgc2lnbmF0dXJlIHByb3ZpZGVyIGFuZCBlbmRwb2ludCBib3VuZFxyXG4gICAgICogdG8gaXQuIEFkZHMgYSBsZXZlbCBvZiBzZWN1cml0eSBvdmVyIHNpZ25hdHVyZSBwcm92aWRlciBtYW5pcHVsYXRpb24uXHJcbiAgICAgKiBObyBtYXR0ZXIgd2hhdCBvcHRpb25zIGFyZSBwcm92aWRlZCwgaHR0cEVuZHBvaW50IGFuZCBzaWduUHJvdmlkZXIgYXJlIGFsd2F5cyBvdmVyd3JpdHRlbi5cclxuICAgICAqIEBwYXJhbSBfZW9zIC0gQW4gaW5zdGFuY2Ugb2YgRW9zLkxvY2FsbmV0IG9yIEVvcy5UZXN0bmV0XHJcbiAgICAgKiBAcGFyYW0gX25ldHdvcmsgLSBUaGUgbmV0d29yayB5b3UgYXJlIGJpbmRpbmcgdG8ge2hvc3Q6c3RyaW5nLCBwb3J0Om51bWJlcn1cclxuICAgICAqIEBwYXJhbSBfb3B0aW9ucyAtIFBhc3NhYmxlIG9iamVjdCBvZiBlb3NqcyBvcHRpb25zXHJcbiAgICAgKiBAcmV0dXJucyB7Kn1cclxuICAgICAqL1xyXG4gICAgZW9zKF9lb3MsIF9uZXR3b3JrLCBfb3B0aW9ucyA9IHt9KXtcclxuICAgICAgICB0aGlzLl9iaW5kTmV0d29yayhfbmV0d29yaywgaW5zdGFuY2VSZWYpO1xyXG4gICAgICAgIGNvbnN0IGh0dHBFbmRwb2ludCA9IGBodHRwOi8vJHtfbmV0d29yay5ob3N0fToke19uZXR3b3JrLnBvcnR9YDtcclxuICAgICAgICByZXR1cm4gX2VvcyhPYmplY3QuYXNzaWduKF9vcHRpb25zLCB7aHR0cEVuZHBvaW50LCBzaWduUHJvdmlkZXI6IHByb3ZpZGVyfSkpXHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKipcclxuICAgICAqIEdldHMgYW4gSWRlbnRpdHkgZnJvbSB0aGUgdXNlciB0byB1c2UuXHJcbiAgICAgKiBZb3Ugc2hvdWxkbid0IHJlbHkgb24gdGhlIHN0YXRlIG9mIHRoaXMgb2JqZWN0IHRvIGJlIGltbXV0YWJsZS5cclxuICAgICAqIElkZW50aXRpZXMgYXJlIHN1YmplY3QgdG8gY2hhbmdlIGFuZCBpZiB5b3UgdXNlIHZhbHVlcyB5b3Ugc2F2ZWQgaW5cclxuICAgICAqIGEgZGF0YWJhc2UgdnMgdGhlIHZhbHVlcyBvbiB0aGUgaWRlbnRpdHkgY3VycmVudGx5IHNpZ25hdHVyZSBwcm92aWRlcnMgd2lsbCBub3Qgd29yay5cclxuICAgICAqIEBwYXJhbSBmaWVsZHMgLSBZb3UgY2FuIHNwZWNpZnkgcmVxdWlyZWQgZmllbGRzIHN1Y2ggYXMgWydlbWFpbCcsICdjb3VudHJ5JywgJ2ZpcnN0bmFtZSddXHJcbiAgICAgKi9cclxuICAgIGdldElkZW50aXR5KGZpZWxkcyA9IFtdKXtcclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZChOZXR3b3JrTWVzc2FnZVR5cGVzLkdFVF9PUl9SRVFVRVNUX0lERU5USVRZLCB7XHJcbiAgICAgICAgICAgIGRvbWFpbjpsb2NhdGlvbi5ob3N0LFxyXG4gICAgICAgICAgICBuZXR3b3JrOnRoaXMubmV0d29yayxcclxuICAgICAgICAgICAgZmllbGRzXHJcbiAgICAgICAgfSwgaW5zdGFuY2VSZWYpO1xyXG4gICAgfVxyXG5cclxufVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vc3JjL3NjYXR0ZXJkYXBwLmpzXG4vLyBtb2R1bGUgaWQgPSAxMzVcbi8vIG1vZHVsZSBjaHVua3MgPSAxIDMgNCIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIE5ldHdvcmsge1xyXG4gICAgY29uc3RydWN0b3IoX2hvc3QgPSAnJywgX3BvcnQgPSAwKXtcclxuICAgICAgICB0aGlzLmhvc3QgPSBfaG9zdDtcclxuICAgICAgICB0aGlzLnBvcnQgPSBfcG9ydDtcclxuICAgIH1cclxuXHJcbiAgICBzdGF0aWMgcGxhY2Vob2xkZXIoKXsgcmV0dXJuIG5ldyBOZXR3b3JrKCk7IH1cclxuICAgIHN0YXRpYyBmcm9tSnNvbihqc29uKXsgcmV0dXJuIE9iamVjdC5hc3NpZ24odGhpcy5wbGFjZWhvbGRlcigpLCBqc29uKTsgfVxyXG4gICAgdW5pcXVlKCl7IHJldHVybiBgJHt0aGlzLmhvc3R9OiR7dGhpcy5wb3J0fWA7IH1cclxuICAgIGNsb25lKCl7IHJldHVybiBOZXR3b3JrLmZyb21Kc29uKEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpcykpKSB9XHJcblxyXG4gICAgLyoqKlxyXG4gICAgICogVGhlIGVuZG9yc2VkIFNjYXR0ZXIgbmV0d29yayB0aGF0IGhvbGRzIGl0J3MgY29udHJhY3RzXHJcbiAgICAgKiBAcmV0dXJucyB7TmV0d29ya31cclxuICAgICAqL1xyXG4gICAgc3RhdGljIGVuZG9yc2VkTmV0d29yaygpeyByZXR1cm4gbmV3IE5ldHdvcmsoJ21haW5uZXQuZW9zLmlvJywgODA4MCk7IH1cclxuXHJcbiAgICAvKioqXHJcbiAgICAgKiBDaGVja3MgaWYgdGhpcyBpcyB0aGUgU2NhdHRlciBlbmRvcnNlZCBuZXR3b3JrXHJcbiAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn1cclxuICAgICAqL1xyXG4gICAgaXNFbmRvcnNlZE5ldHdvcmsoKXsgcmV0dXJuIHRoaXMuaG9zdCA9PT0gJ21haW5uZXQuZW9zLmlvJyAmJiB0aGlzLnBvcnQgPT09IDgwODAgfVxyXG5cclxuICAgIC8qKipcclxuICAgICAqIE1ha2VzIHN1cmUgYSBwb3J0IGlzIG5vdCByZXNlcnZlZFxyXG4gICAgICogQHBhcmFtIHBvcnRcclxuICAgICAqIEByZXR1cm5zIHtib29sZWFufVxyXG4gICAgICovXHJcbiAgICBzdGF0aWMgcG9ydElzVmFsaWQocG9ydCl7IHJldHVybiBOdW1iZXIocG9ydCkgPiAxMDAwIHx8IE51bWJlcihwb3J0KSA9PT0gODAgfVxyXG5cclxuICAgIC8vIFRPRE86IE1vY2tcclxuICAgIHN0YXRpYyBob3N0SXNWYWxpZChob3N0KXsgcmV0dXJuIGhvc3QuaW5kZXhPZignLicpID4gLTEgfVxyXG5cclxufVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vc3JjL21vZGVscy9OZXR3b3JrLmpzXG4vLyBtb2R1bGUgaWQgPSAyMVxuLy8gbW9kdWxlIGNodW5rcyA9IDAgMSAyIDMgNCIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIElkR2VuZXJhdG9yIHtcclxuXHJcbiAgICAvKioqXHJcbiAgICAgKiBHZW5lcmF0ZXMgYSByYW5kb20gc3RyaW5nIG9mIHNwZWNpZmllZCBzaXplXHJcbiAgICAgKiBAcGFyYW0gc2l6ZSAtIFRoZSBsZW5ndGggb2YgdGhlIHN0cmluZyB0byBnZW5lcmF0ZVxyXG4gICAgICogQHJldHVybnMge3N0cmluZ30gLSBUaGUgZ2VuZXJhdGVkIHJhbmRvbSBzdHJpbmdcclxuICAgICAqL1xyXG4gICAgc3RhdGljIHRleHQoc2l6ZSl7XHJcbiAgICAgICAgbGV0IHRleHQgPSBcIlwiO1xyXG4gICAgICAgIGNvbnN0IHBvc3NpYmxlID0gXCJBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OVwiO1xyXG4gICAgICAgIGZvcihsZXQgaT0wOyBpPHNpemU7IGkrKykgdGV4dCArPSBwb3NzaWJsZS5jaGFyQXQoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogcG9zc2libGUubGVuZ3RoKSk7XHJcbiAgICAgICAgcmV0dXJuIHRleHQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKlxyXG4gICAgICogR2VuZXJhdGVzIGEgcmFuZG9tIG51bWJlciBvZiBzcGVjaWZpZWQgc2l6ZVxyXG4gICAgICogQHBhcmFtIHNpemUgLSBUaGUgbGVuZ3RoIG9mIHRoZSBudW1iZXIgdG8gZ2VuZXJhdGVcclxuICAgICAqIEByZXR1cm5zIHtzdHJpbmd9IC0gVGhlIGdlbmVyYXRlZCByYW5kb20gbnVtYmVyICggYXMgYSBzdHJpbmcgKVxyXG4gICAgICovXHJcbiAgICBzdGF0aWMgbnVtZXJpYyhzaXplKXtcclxuICAgICAgICBjb25zdCBhZGQgPSAxO1xyXG4gICAgICAgIGxldCBtYXggPSAxMiAtIGFkZDtcclxuXHJcbiAgICAgICAgaWYgKCBzaXplID4gbWF4ICkgcmV0dXJuIElkR2VuZXJhdG9yLm51bWVyaWMobWF4KSArIElkR2VuZXJhdG9yLm51bWVyaWMoc2l6ZSAtIG1heCk7XHJcblxyXG4gICAgICAgIG1heCA9IE1hdGgucG93KDEwLCBzaXplK2FkZCk7XHJcbiAgICAgICAgY29uc3QgbWluID0gbWF4IC8gMTAsXHJcbiAgICAgICAgICAgICAgbnVtYmVyID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogKG1heCAtIG1pbiArIDEpKSArIG1pbjtcclxuXHJcbiAgICAgICAgcmV0dXJuIChcIlwiICsgbnVtYmVyKS5zdWJzdHJpbmcoYWRkKTtcclxuICAgIH1cclxuXHJcbn1cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL3NyYy91dGlsL0lkR2VuZXJhdG9yLmpzXG4vLyBtb2R1bGUgaWQgPSAzMFxuLy8gbW9kdWxlIGNodW5rcyA9IDAgMSAyIDMgNCIsImV4cG9ydCBjb25zdCBFUlJPUiA9ICdlcnJvcic7XHJcbmV4cG9ydCBjb25zdCBQVVNIX1NDQVRURVIgPSAncHVzaFNjYXR0ZXInO1xyXG5leHBvcnQgY29uc3QgR0VUX09SX1JFUVVFU1RfSURFTlRJVFkgPSAnZ2V0T3JSZXF1ZXN0SWRlbnRpdHknO1xyXG5leHBvcnQgY29uc3QgUkVRVUVTVF9TSUdOQVRVUkUgPSAncmVxdWVzdFNpZ25hdHVyZSc7XG5cblxuLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBXRUJQQUNLIEZPT1RFUlxuLy8gLi9zcmMvbWVzc2FnZXMvTmV0d29ya01lc3NhZ2VUeXBlcy5qc1xuLy8gbW9kdWxlIGlkID0gNTdcbi8vIG1vZHVsZSBjaHVua3MgPSAxIDMgNCJdLCJzb3VyY2VSb290IjoiIn0=